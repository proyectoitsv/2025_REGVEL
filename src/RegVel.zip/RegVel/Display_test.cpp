/* ===========================================================================
   Display_test.cpp
   Implementación del módulo de Display y LEDs (Core 1).
   ============================================================================= */

#include "Display_test.h"
#include "Motor_ADC_test.h" // Para llamar a motor_get_speed_kmh()

// ============================================================================
// VARIABLES GLOBALES ESTÁTICAS (ENCAPSULADAS EN ESTE MÓDULO)
// ============================================================================

// --- Estado del Display 7 Segmentos ---
static uint16_t display_current_value = 0;      // Valor actual mostrado
static uint8_t display_current_digit = 0;       // Dígito actualmente multiplexado (0-2)
static uint32_t display_last_multiplex_us = 0;  // Timestamp del último cambio de dígito
static uint8_t display_digits[3] = {0, 0, 0};   // [centenas, decenas, unidades]

// --- Estado de los LEDs ---
static bool speed_limit_active = false;
static uint32_t last_led_update_ms = 0;

// ============================================================================
// FUNCIONES AUXILIARES Y PRIVADAS DEL MÓDULO
// ============================================================================

/**
 * @brief Escribe un dígito BCD (0-9) en los pines del CD4511BE.
 * @param digit Dígito a mostrar (0-9).
 */
static inline void write_bcd_digit(uint8_t digit) {
  if (digit > 9) digit = 9;
  digitalWrite(DISP_BCD_BIT1_PIN, (digit & 0x01) ? HIGH : LOW); // LSB
  digitalWrite(DISP_BCD_BIT2_PIN, (digit & 0x02) ? HIGH : LOW);
  digitalWrite(DISP_BCD_BIT3_PIN, (digit & 0x04) ? HIGH : LOW);
  digitalWrite(DISP_BCD_BIT4_PIN, (digit & 0x08) ? HIGH : LOW); // MSB
}

/**
 * @brief Activa o desactiva un dígito específico del display.
 * @param digit_index Índice del dígito (0=centenas, 1=decenas, 2=unidades).
 * @param state true para activar, false para desactivar.
 */
static inline void set_digit_active(uint8_t digit_index, bool state) {
  bool pin_state = DISP_COMMON_ANODE ? !state : state;
  switch(digit_index) {
    case 0: digitalWrite(DISP_DIGIT1_PIN, pin_state); break;
    case 1: digitalWrite(DISP_DIGIT2_PIN, pin_state); break;
    case 2: digitalWrite(DISP_DIGIT3_PIN, pin_state); break;
  }
}

/**
 * @brief Descompone un número en dígitos individuales.
 * @param value Número a descomponer (0-999).
 */
static void decompose_number(uint16_t value) {
  if (value > 999) value = 999;
  display_digits[0] = (value / 100) % 10;
  display_digits[1] = (value / 10) % 10;
  display_digits[2] = value % 10;
  display_current_value = value;
}

/**
 * @brief Apaga todos los LEDs de umbral de velocidad.
 */
static void speed_leds_off() {
  digitalWrite(LED_LIM1_PIN, LOW);
  digitalWrite(LED_LIM2_PIN, LOW);
  digitalWrite(LED_LIM3_PIN, LOW);
  digitalWrite(LED_LIM4_PIN, LOW);
}

// ============================================================================
// IMPLEMENTACIÓN DE FUNCIONES PÚBLICAS (DECLARADAS EN EL .H)
// ============================================================================

void display_init() {
  Serial.println("Iniciando módulo de Display y LEDs...");

  // --- Inicialización Pines Display ---
  pinMode(DISP_BCD_BIT1_PIN, OUTPUT);
  pinMode(DISP_BCD_BIT2_PIN, OUTPUT);
  pinMode(DISP_BCD_BIT3_PIN, OUTPUT);
  pinMode(DISP_BCD_BIT4_PIN, OUTPUT);
  pinMode(DISP_DIGIT1_PIN, OUTPUT);
  pinMode(DISP_DIGIT2_PIN, OUTPUT);
  pinMode(DISP_DIGIT3_PIN, OUTPUT);

  // --- Inicialización Pines LEDs ---
  pinMode(LED_LIM1_PIN, OUTPUT);
  pinMode(LED_LIM2_PIN, OUTPUT);
  pinMode(LED_LIM3_PIN, OUTPUT);
  pinMode(LED_LIM4_PIN, OUTPUT);
  pinMode(LED_LIMIT_PIN, OUTPUT);
  pinMode(LED_OK_PIN, OUTPUT);

  // --- Estado Inicial ---
  speed_leds_off();
  digitalWrite(LED_LIMIT_PIN, LOW);
  digitalWrite(LED_OK_PIN, HIGH); // Sistema OK al inicio
  decompose_number(0);
  display_last_multiplex_us = micros();
  last_led_update_ms = millis();

  Serial.println("Módulo de Display y LEDs inicializado.");
}

void display_update_speed(float speed_kmh) {
  // 1. Actualizar LEDs de umbral
  digitalWrite(LED_LIM1_PIN, (speed_kmh >= LED_LIM1_THRESHOLD) ? HIGH : LOW);
  digitalWrite(LED_LIM2_PIN, (speed_kmh >= LED_LIM2_THRESHOLD) ? HIGH : LOW);
  digitalWrite(LED_LIM3_PIN, (speed_kmh >= LED_LIM3_THRESHOLD) ? HIGH : LOW);
  digitalWrite(LED_LIM4_PIN, (speed_kmh >= LED_LIM4_THRESHOLD) ? HIGH : LOW);

  // 2. Actualizar valor del display
  uint16_t display_speed = (uint16_t)constrain(speed_kmh, 0, 999);
  decompose_number(display_speed);
}

void display_refresh() {
  uint32_t current_us = micros();
  
  if ((current_us - display_last_multiplex_us) >= DISP_MULTIPLEX_DELAY_US) {
    // Apagar todos los dígitos para evitar ghosting
    set_digit_active(0, false);
    set_digit_active(1, false);
    set_digit_active(2, false);
    
    // Escribir y activar el dígito actual
    write_bcd_digit(display_digits[display_current_digit]);
    set_digit_active(display_current_digit, true);
    
    // Avanzar al siguiente dígito
    display_current_digit = (display_current_digit + 1) % 3;
    display_last_multiplex_us = current_us;
  }
}

void display_apply_speed_limit(const InterCoreMsg& msg) {
  if (!msg.valid) return;
  
  speed_limit_active = msg.inside_zone;
  
  digitalWrite(LED_LIMIT_PIN, speed_limit_active ? HIGH : LOW);
  digitalWrite(LED_OK_PIN, speed_limit_active ? LOW : HIGH);
  
  Serial.printf("[Display] Indicador de límite: %s\n", speed_limit_active ? "ACTIVO" : "INACTIVO");
}

// ============================================================================
// IMPLEMENTACIÓN DE LA TAREA FREERTOS (CORE 1)
// ============================================================================

void taskDisplay(void *pvParameters) {
  Serial.println("[Core 1] Tarea Display iniciada.");
  
  InterCoreMsg received_msg;
  
  while (true) {
    // 1. Comprobar si hay mensajes de límite de velocidad
    if (xQueueReceive(zone_queue, &received_msg, pdMS_TO_TICKS(10)) == pdPASS) {
      display_apply_speed_limit(received_msg);
    }

    // 2. Obtener la velocidad actual desde el módulo del motor
    float current_speed = motor_get_speed_kmh();

    // 3. Actualizar todos los elementos visuales
    display_update_speed(current_speed);
    
    // 4. Refrescar el display (alta frecuencia)
    display_refresh();
    
    // 5. Ceder tiempo de CPU
    vTaskDelay(pdMS_TO_TICKS(10));
  }
}