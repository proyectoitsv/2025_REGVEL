/* ===========================================================================
   Display_test.h
   Cabecera del módulo de Display y LEDs (Core 1).
   Responsabilidades:
   - Inicializar el display de 7 segmentos y los LEDs indicadores.
   - Actualizar el estado de los LEDs de umbral de velocidad.
   - Actualizar el número mostrado en el display de 7 segmentos.
   - Gestionar el refresco multiplexado del display.
   - Indicar visualmente cuando un límite de velocidad está activo.
   ============================================================================= */

#ifndef DISPLAY_TEST_H
#define DISPLAY_TEST_H

#include "config.h"

// ============================================================================
// FUNCIONES PÚBLICAS DEL MÓDULO
// ============================================================================

/**
 * @brief Inicializa el módulo de visualización.
 * Configura los pines del display 7 segmentos, los LEDs de umbral
 * y los LEDs de estado. Debe ser llamada una sola vez al inicio.
 */
void display_init();

/**
 * @brief Actualiza todos los elementos visuales con la velocidad actual.
 * Esta función coordina la actualización de:
 * - Los LEDs de umbral de velocidad.
 * - El número mostrado en el display de 7 segmentos.
 * @param speed_kmh Velocidad actual en km/h.
 */
void display_update_speed(float speed_kmh);

/**
 * @brief Refresca el display de 7 segmentos.
 * Esta función gestiona el multiplexado de los dígitos y debe ser llamada
 * con alta frecuencia (cada 10-20ms) para mantener el display visible
 * sin parpadeo. Es una función no bloqueante.
 */
void display_refresh();

/**
 * @brief Aplica una decisión de límite de velocidad a los indicadores visuales.
 * Enciende o apaga el LED que indica que el sistema está en una zona
 * con límite de velocidad activo.
 * @param msg Mensaje de inter-core con la información del límite.
 */
void display_apply_speed_limit(const InterCoreMsg& msg);

// ============================================================================
// TAREA FREERTOS (CORE 1)
// ============================================================================

/**
 * @brief Tarea de FreeRTOS que se ejecuta en el Core 1.
 * Gestiona el ciclo de vida del display:
 * 1. Espera y procesa mensajes de límite de velocidad de la cola.
 * 2. Obtiene la velocidad actual desde el módulo del motor.
 * 3. Actualiza los indicadores visuales llamando a display_update_speed().
 * 4. Ejecuta el refresco del display en un bucle rápido.
 * @param pvParameters Parámetros de la tarea (no utilizados en este caso).
 */
void taskDisplay(void *pvParameters);

#endif // DISPLAY_TEST_H