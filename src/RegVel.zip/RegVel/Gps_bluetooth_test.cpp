/* ===========================================================================
   Gps_bluetooth_test.cpp
   Implementación del módulo GPS/Bluetooth (Core 0).
   ============================================================================= */

#include "Gps_bluetooth_test.h"

// ============================================================================
// VARIABLES GLOBALES ESTÁTICAS (ENCAPSULADAS EN ESTE MÓDULO)
// ============================================================================

// Instancia de Bluetooth
// En Gps_bluetooth_test.cpp, en la sección de variables globales estáticas, reemplaza la línea anterior por:
extern BluetoothSerial SerialBT;

// Estado del sistema
static volatile bool timer_flag = false;
static volatile bool bt_connected = false;
static volatile unsigned long chars_received = 0;
static volatile unsigned long last_bt_data = 0;
static bool system_error = false;

// Datos GPS protegidos con mutex
static volatile GpsFix current_gps = {0.0, 0.0, 0.0, 0.0, 0.0, 0, false, 0};
static portMUX_TYPE gps_mux = portMUX_INITIALIZER_UNLOCKED;

// Handle del timer de hardware
static hw_timer_t *gps_timer = NULL;

// Parser NMEA ligero
#define NMEA_BUFFER_SIZE 128
static char nmea_buffer[NMEA_BUFFER_SIZE];
static uint8_t nmea_idx = 0;

// Mensaje de zona local (solo usado dentro de este módulo)
struct ZoneMessage {
  bool inside_zone;
  uint8_t speed_limit;
  float current_speed;
  char zone_name[20];
  bool valid;
  uint32_t timestamp;
};

// ============================================================================
// FUNCIONES AUXILIARES Y PRIVADAS DEL MÓDULO
// ============================================================================

/**
 * @brief ISR del timer hardware. Marca la bandera para procesar GPS.
 */
void IRAM_ATTR onTimer() {
  timer_flag = true;
}

/**
 * @brief Convierte una coordenada NMEA (DDMM.MMMM) a grados decimales.
 */
static double gps_convert_coord(const char* field) {
  if (field == NULL || field[0] == '\0') return 0.0;
  double degrees, minutes;
  char* dot_pos = (char*)strchr(field, '.');
  if (dot_pos == NULL || dot_pos - field < 3) return 0.0;
  uint8_t len_deg = (dot_pos - field) - 2;
  char buf_deg[4];
  strncpy(buf_deg, field, len_deg);
  buf_deg[len_deg] = '\0';
  degrees = atof(buf_deg);
  minutes = atof(field + len_deg);
  return degrees + (minutes / 60.0);
}

/**
 * @brief Parsea una sentencia NMEA GPRMC y actualiza la estructura global de GPS.
 */
static bool gps_parse_rmc(const char* sentence) {
  if (strncmp(sentence, "$GPRMC", 6) != 0) return false;

  // Campo 2: Validez ('A' = OK, 'V' = Warning)
  const char* validity = strchr(sentence, ',');
  if (validity == NULL || *(++validity) != 'A') return false;

  GpsFix temp_data;
  temp_data.valid = true;

  // Campo 3: Latitud
  const char* lat_field = strchr(validity, ',');
  temp_data.lat = gps_convert_coord(++lat_field);

  // Campo 4: N/S
  const char* ns_field = strchr(lat_field, ',');
  if (ns_field != NULL && *(++ns_field) == 'S') temp_data.lat = -temp_data.lat;

  // Campo 5: Longitud
  const char* lon_field = strchr(ns_field, ',');
  temp_data.lon = gps_convert_coord(++lon_field);

  // Campo 6: E/W
  const char* ew_field = strchr(lon_field, ',');
  if (ew_field != NULL && *(++ew_field) == 'W') temp_data.lon = -temp_data.lon;

  // Campo 7: Velocidad (Nudos -> km/h)
  const char* speed_field = strchr(ew_field, ',');
  temp_data.speedKph = atof(++speed_field) * 1.852f;

  // Campo 8: Rumbo
  const char* course_field = strchr(speed_field, ',');
  temp_data.courseDeg = atof(++course_field);
  
  temp_data.hdop = 0.0; // No disponible en GPRMC
  temp_data.satellites = 0; // No disponible en GPRMC
  temp_data.timestamp = millis();
  
  // Actualización segura de la variable global
  taskENTER_CRITICAL(&gps_mux);
  memcpy((void*)&current_gps, &temp_data, sizeof(GpsFix));
  taskEXIT_CRITICAL(&gps_mux);

  return true;
}

/**
 * @brief Inicializa la comunicación Bluetooth.
 */
static void bt_init() {
  SerialBT.begin(BT_NAME);
  Serial.println(FPSTR(LOG_PREFIX_INFO));
  Serial.printf("Bluetooth iniciado: %s\n", BT_NAME);
  Serial.println("Esperando conexion del Master...");
}

/**
 * @brief Lee datos desde Bluetooth y los procesa.
 */
static void gps_process_bluetooth_data() {
  if (!bt_is_connected()) return;
  
  while (SerialBT.available()) {
    char c = SerialBT.read();
    chars_received++;
    last_bt_data = millis();

    if (c == '$') nmea_idx = 0;
    
    if (nmea_idx < NMEA_BUFFER_SIZE - 1) {
      nmea_buffer[nmea_idx++] = c;
      if (c == '\n' || c == '\r') {
        nmea_buffer[nmea_idx] = '\0';
        if (nmea_idx > 6 && strncmp(nmea_buffer, "$GPRMC", 6) == 0) {
          gps_parse_rmc(nmea_buffer);
        }
        nmea_idx = 0;
      }
    } else {
      nmea_idx = 0; // Buffer overflow
    }
  }
}

/**
 * @brief Devuelve el nombre de la zona según la posición.
 */
static const char* zone_get_name(bool inside) {
  return inside ? "CENTRO" : "PERIFERIA";
}

/**
 * @brief Envía un mensaje a la cola inter-core.
 */
static bool send_zone_message(const ZoneMessage& msg) {
  if (zone_queue == NULL) return false;
  InterCoreMsg core_msg;
  core_msg.inside_zone = msg.inside_zone;
  core_msg.speed_limit = msg.speed_limit;
  core_msg.valid = msg.valid;
  return xQueueSend(zone_queue, &core_msg, pdMS_TO_TICKS(100)) == pdTRUE;
}

/**
 * @brief Comprueba si la posición GPS está dentro de una zona definida.
 */
static void zone_check_position(const GpsFix& gps_data) {
  // TODO: Estas coordenadas deberían cargarse desde un archivo o configuración.
  const double ZONA_CENTRO_LAT_MIN = 41.37;
  const double ZONA_CENTRO_LAT_MAX = 41.40;
  const double ZONA_CENTRO_LON_MIN = 2.16;
  const double ZONA_CENTRO_LON_MAX = 2.19;
  
  bool inside = (gps_data.lat >= ZONA_CENTRO_LAT_MIN && 
                 gps_data.lat <= ZONA_CENTRO_LAT_MAX &&
                 gps_data.lon >= ZONA_CENTRO_LON_MIN && 
                 gps_data.lon <= ZONA_CENTRO_LON_MAX);
  
  uint8_t limit = inside ? 30 : 50;
  
  ZoneMessage msg;
  msg.inside_zone = inside;
  msg.speed_limit = limit;
  msg.current_speed = gps_data.speedKph;
  strncpy(msg.zone_name, zone_get_name(inside), sizeof(msg.zone_name) - 1);
  msg.valid = true;
  msg.timestamp = millis();
  
  send_zone_message(msg);
  
  Serial.printf("[GPS] Zona: %s | Limite: %d | Vel: %.1f km/h\n",
                msg.zone_name, limit, gps_data.speedKph);
}

// ============================================================================
// IMPLEMENTACIÓN DE FUNCIONES PÚBLICAS (DECLARADAS EN EL .H)
// ============================================================================

void gps_init() {
  Serial.println("Iniciando módulo GPS/Bluetooth...");
  
  bt_init();

  // Configuración del Timer Hardware
  gps_timer = timerBegin(0); 
  if (!gps_timer) {
    Serial.println(FPSTR(LOG_PREFIX_ERROR));
    Serial.println("Fallo al inicializar el Timer HW");
    system_error = true;
    return;
  }
  
  timerAttachInterrupt(gps_timer, &onTimer);
  timerAlarm(gps_timer, TIMER_INTERVAL_US, true, 0);
  
  Serial.println("Módulo GPS/Bluetooth inicializado.");
}

bool gps_get_fix(GpsFix& fix) {
  portENTER_CRITICAL(&gps_mux);
  memcpy(&fix, (void*)&current_gps, sizeof(GpsFix));
  portEXIT_CRITICAL(&gps_mux);
  
  return fix.valid && (millis() - fix.timestamp < 5000);
}

bool bt_is_connected() {
  return SerialBT.hasClient();
}

// ============================================================================
// IMPLEMENTACIÓN DE LA TAREA FREERTOS (CORE 0)
// ============================================================================

void taskGPS(void *pvParameters) {
  Serial.println("[Core 0] Tarea GPS iniciada.");
  
  // Esperar a que el Bluetooth se conecte
  while (!bt_is_connected()) {
    vTaskDelay(pdMS_TO_TICKS(1000));
    Serial.println("[GPS] Esperando conexión Bluetooth...");
  }
  bt_connected = true;
  Serial.println("[GPS] Master conectado.");
  
  GpsFix gps_fix;
  
  while (true) {
    // Procesar datos entrantes de forma continua
    gps_process_bluetooth_data();
    
    // Lógica síncrona cada segundo (via timer_flag)
    if (timer_flag) {
      timer_flag = false;
      
      if (gps_get_fix(gps_fix)) {
        zone_check_position(gps_fix);
      }
    }
    
    // Ceder tiempo de CPU para no bloquear
    vTaskDelay(pdMS_TO_TICKS(10));
  }
}