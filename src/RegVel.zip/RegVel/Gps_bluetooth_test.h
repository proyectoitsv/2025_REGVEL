/* ===========================================================================
   Gps_bluetooth_test.h
   Cabecera del módulo GPS/Bluetooth (Core 0).
   Responsabilidades:
   - Inicializar y gestionar la conexión Bluetooth como Slave.
   - Leer datos NMEA desde el Bluetooth.
   - Parsear las sentencias NMEA para obtener coordenadas y velocidad.
   - Evaluar la posición contra zonas predefinidas.
   - Enviar mensajes de límite de velocidad a la cola inter-core para el Core 1.
   ============================================================================= */

#ifndef GPS_BLUETOOTH_TEST_H
#define GPS_BLUETOOTH_TEST_H

#include "config.h"
#include <BluetoothSerial.h> // yo lo agregué
// ============================================================================
// VARIABLES GLOBALES EXTERNAS (DEFINIDAS EN RegVel.ino)
// ============================================================================
// Declaración de la cola para comunicación inter-core. El módulo GPS escribirá en ella.
extern QueueHandle_t zone_queue;

// ============================================================================
// FUNCIONES PÚBLICAS DEL MÓDULO
// ============================================================================

/**
 * @brief Inicializa el módulo GPS y Bluetooth.
 * Configura el Serial Bluetooth, el timer hardware para sincronización
 * y otros componentes necesarios. Debe ser llamada una sola vez al inicio.
 */
void gps_init();

/**
 * @brief Obtiene el último fix válido del GPS.
 * @param fix Estructura GpsFix donde se almacenarán los datos de posición y velocidad.
 * @return true si se obtuvo un fix válido y reciente, false en caso contrario.
 */
bool gps_get_fix(GpsFix& fix);

/**
 * @brief Verifica el estado de la conexión Bluetooth.
 * @return true si hay un cliente conectado, false en caso contrario.
 */
bool bt_is_connected();

// ============================================================================
// TAREA FREERTOS (CORE 0)
// ============================================================================

/**
 * @brief Tarea de FreeRTOS que se ejecuta en el Core 0.
 * Gestiona todo el ciclo de vida del GPS:
 * 1. Espera la conexión Bluetooth.
 * 2. Lee y procesa datos NMEA de forma continua.
 * 3. Cada segundo (via timer flag), obtiene un fix y evalúa la zona.
 * 4. Envía mensajes de límite de velocidad a la cola `zone_queue`.
 * @param pvParameters Parámetros de la tarea (no utilizados en este caso).
 */
void taskGPS(void *pvParameters);

#endif // GPS_BLUETOOTH_TEST_H