/* ===========================================================================
   Motor_ADC_test.cpp
   Implementación del módulo de Control de Motor y ADC (Core 1).
   ============================================================================= */

#include "Motor_ADC_test.h"

// ============================================================================
// VARIABLES GLOBALES ESTÁTICAS (ENCAPSULADAS EN ESTE MÓDULO)
// ============================================================================

// --- Estado del Acelerador (ADC y PWM) ---
static float smoothed_adc_value = 0.0f;
static float current_duty_percent = MIN_SAFE_DUTY;
static float target_duty_percent = MIN_SAFE_DUTY;
static uint32_t last_ramp_ms = 0;
static bool accelerator_initialized = false;

// --- Estado del Sensor Hall ---
static volatile uint32_t hall_pulse_count = 0;
static uint32_t hall_last_time = 0;
static float hall_rpm = 0.0f;
static float current_speed_kmh = 0.0f;
static uint32_t last_speed_calc_ms = 0;

// --- Estado de la Lógica de Límite ---
static bool speed_limit_active = false;
static uint16_t current_speed_limit = 0;

// ============================================================================
// FUNCIONES AUXILIARES Y PRIVADAS DEL MÓDULO
// ============================================================================

/**
 * @brief ISR del sensor Hall. Incrementa el contador de pulsos.
 */
void IRAM_ATTR hall_isr() {
  hall_pulse_count++;
}

/**
 * @brief Calcula las RPM actuales del motor.
 * @return RPM calculadas desde los pulsos del sensor.
 */
static float hall_get_rpm() {
  uint32_t current_time = millis();
  uint32_t time_diff = current_time - hall_last_time;
  
  if (time_diff >= 1000) {
    noInterrupts();
    uint32_t pulses = hall_pulse_count;
    hall_pulse_count = 0;
    interrupts();
    
    hall_last_time = current_time;
    hall_rpm = (float)pulses * 60.0f / ((float)time_diff / 1000.0f) / (float)HALL_PULSES_PER_REV;
  }
  
  return hall_rpm;
}

/**
 * @brief Convierte RPM del motor a velocidad en km/h.
 * @param rpm Revoluciones por minuto.
 * @return Velocidad en km/h.
 */
static float rpm_to_speed_kmh(float rpm) {
  if (rpm < 0.1f) return 0.0f;
  
  float circumference_m = PI * WHEEL_CIRCUMFERENCE_M;
  float speed_real_mps = (rpm * circumference_m) / 60.0f;
  float speed_real_kmh = speed_real_mps * 3.6f;
  
  // Aplicar umbral mínimo para evitar fluctuaciones
  if (speed_real_kmh < 1.0f) {
    return 0.0f;
  }
  
  return speed_real_kmh;
}

/**
 * @brief Aplica la política de limitación al duty calculado por el pedal.
 * @param duty_from_pedal Duty base calculado del ADC (0-255).
 * @param measured_speed_kmh Velocidad real del vehículo.
 * @return Duty final a aplicar al motor.
 */
static uint8_t apply_speed_limit_to_duty(uint8_t duty_from_pedal, float measured_speed_kmh) {
  if (!speed_limit_active || current_speed_limit == 0) {
    return max((int)duty_from_pedal, MIN_SAFE_DUTY);
  }

  if (measured_speed_kmh <= (float)current_speed_limit - 0.5f) {
    return max((int)duty_from_pedal, MIN_SAFE_DUTY);
  }

  // Si superamos el límite: reducir duty proporcionalmente
  float excess = measured_speed_kmh - (float)current_speed_limit;
  float factor = 1.0f - (excess / max(1.0f, measured_speed_kmh));
  if (factor < 0.0f) factor = 0.0f;
  
  uint8_t limited_duty = (uint8_t) round((float)duty_from_pedal * factor);
  if (limited_duty < MIN_SAFE_DUTY) limited_duty = MIN_SAFE_DUTY;
  
  return limited_duty;
}

// ============================================================================
// IMPLEMENTACIÓN DE FUNCIONES PÚBLICAS (DECLARADAS EN EL .H)
// ============================================================================

void motor_init() {
  Serial.println("Iniciando módulo de Control de Motor...");

  // --- Inicialización ADC ---
  analogReadResolution(12); // 0..4095
  analogSetPinAttenuation(PEDAL_ADC_PIN, PEDAL_ADC_ATTENUATION);
  int init_raw = analogRead(PEDAL_ADC_PIN);
  smoothed_adc_value = (float)init_raw;

  // --- Inicialización PWM (LEDC) ---
  ledc_timer_config_t timer_conf;
  timer_conf.speed_mode = LEDC_LOW_SPEED_MODE;
  timer_conf.duty_resolution = (ledc_timer_bit_t)MOTOR_PWM_RES;
  timer_conf.timer_num = (ledc_timer_t)PWM_TIMER;
  timer_conf.freq_hz = MOTOR_PWM_FREQ;
  timer_conf.clk_cfg = LEDC_AUTO_CLK;
  ledc_timer_config(&timer_conf);

  ledc_channel_config_t channel_conf;
  channel_conf.gpio_num = (gpio_num_t)MOTOR_PWM_PIN;
  channel_conf.speed_mode = LEDC_LOW_SPEED_MODE;
  channel_conf.channel = (ledc_channel_t)PWM_CHANNEL;
  channel_conf.timer_sel = (ledc_timer_t)PWM_TIMER;
  channel_conf.duty = 0;
  channel_conf.hpoint = 0;
  ledc_channel_config(&channel_conf);

  // --- Inicialización Sensor Hall ---
  pinMode(HALL_PIN, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(HALL_PIN), hall_isr, RISING);
  hall_last_time = millis();
  hall_pulse_count = 0;

  // --- Estado inicial ---
  current_duty_percent = MIN_SAFE_DUTY;
  target_duty_percent = MIN_SAFE_DUTY;
  last_ramp_ms = millis();
  accelerator_initialized = true;

  Serial.println("Módulo de Control de Motor inicializado.");
}

void motor_update() {
  if (!accelerator_initialized) return;

  // 1. Leer y suavizar ADC
  int raw_adc = analogRead(PEDAL_ADC_PIN);
  if (raw_adc < 0 || raw_adc > ADC_MAX_READING) return;
  
  smoothed_adc_value = (0.1f * (float)raw_adc) + (0.9f * smoothed_adc_value); // EMA simple
  float norm = smoothed_adc_value / (float)ADC_MAX_READING;
  norm = constrain(norm, 0.0f, 1.0f);
  uint8_t duty_base = (uint8_t) roundf(norm * (float)(DEFAULT_MAX_DUTY - MIN_SAFE_DUTY)) + MIN_SAFE_DUTY;

  // 2. Obtener velocidad actual
  float speed = motor_get_speed_kmh();

  // 3. Aplicar límite de velocidad
  uint8_t duty_final = apply_speed_limit_to_duty(duty_base, speed);

  // 4. Aplicar rampa suave al duty
  uint32_t now = millis();
  uint32_t elapsed = now - last_ramp_ms;
  if (elapsed > 0) {
    float step = 2.0f * ((float)elapsed / 20.0f); // 2% por 20ms
    if (fabs(target_duty_percent - current_duty_percent) <= step) {
      current_duty_percent = target_duty_percent;
    } else if (duty_final > current_duty_percent) {
      current_duty_percent += step;
    } else {
      current_duty_percent -= step;
    }
    last_ramp_ms = now;
  }
  
  // 5. Actualizar PWM
  uint32_t max_duty_value = (1u << MOTOR_PWM_RES) - 1u;
  uint32_t duty_value = (uint32_t) roundf((current_duty_percent / 100.0f) * (float)max_duty_value);
  ledcWrite(MOTOR_PWM_CHANNEL, duty_value);
}

float motor_get_speed_kmh() {
  uint32_t now = millis();
  if ((now - last_speed_calc_ms) >= MS_PER_CALC) {
    float rpm = hall_get_rpm();
    current_speed_kmh = rpm_to_speed_kmh(rpm);
    last_speed_calc_ms = now;
  }
  return current_speed_kmh;
}

void motor_apply_speed_limit(const InterCoreMsg& msg) {
  if (!msg.valid) return;
  
  speed_limit_active = msg.inside_zone;
  current_speed_limit = msg.speed_limit;
  
  Serial.printf("[Motor] Límite aplicado: %s, límite=%u km/h\n",
                speed_limit_active ? "DENTRO" : "FUERA", current_speed_limit);
}

// ============================================================================
// IMPLEMENTACIÓN DE LA TAREA FREERTOS (CORE 1)
// ============================================================================

void taskMotor(void *pvParameters) {
  Serial.println("[Core 1] Tarea Motor iniciada.");
  
  InterCoreMsg received_msg;
  
  while (true) {
    // 1. Comprobar si hay mensajes de límite de velocidad
    if (xQueueReceive(zone_queue, &received_msg, pdMS_TO_TICKS(10)) == pdPASS) {
      motor_apply_speed_limit(received_msg);
    }

    // 2. Ejecutar la lógica de control del motor
    motor_update();
    
    // 3. Ceder tiempo de CPU para mantener un ciclo de ~50Hz
    vTaskDelay(pdMS_TO_TICKS(20));
  }
}