/* ===========================================================================
   Motor_ADC_test.h
   Cabecera del módulo de Control de Motor y ADC (Core 1).
   Responsabilidades:
   - Inicializar y gestionar el ADC del pedal de aceleración.
   - Inicializar y gestionar el PWM para el control del motor.
   - Inicializar y gestionar el sensor Hall para medir velocidad.
   - Calcular la velocidad en km/h a partir de las RPM del sensor Hall.
   - Aplicar límites de velocidad recibidos desde el Core 0.
   - Ejecutar la lógica de control principal (leer pedal, calcular duty, aplicar PWM).
   ============================================================================= */

#ifndef MOTOR_ADC_TEST_H
#define MOTOR_ADC_TEST_H

#include "config.h"

// ============================================================================
// VARIABLES GLOBALES EXTERNAS (DEFINIDAS EN RegVel.ino)
// ============================================================================
// Declaración de la cola para comunicación inter-core. El módulo Motor leerá de ella.
extern QueueHandle_t zone_queue;

// ============================================================================
// FUNCIONES PÚBLICAS DEL MÓDULO
// ============================================================================

/**
 * @brief Inicializa el módulo de control del motor.
 * Configura el ADC del pedal, el canal PWM para el motor y la interrupción
 * del sensor Hall. Debe ser llamada una sola vez al inicio.
 */
void motor_init();

/**
 * @brief Ejecuta un ciclo completo de la lógica de control del motor.
 * Esta función realiza las siguientes acciones:
 * 1. Lee el valor del ADC del pedal.
 * 2. Calcula el ciclo de trabajo (duty) objetivo.
 * 3. Aplica un rampado suave al duty para evitar aceleraciones bruscas.
 * 4. Verifica si hay un mensaje de límite de velocidad en la cola.
 * 5. Aplica el límite si es necesario.
 * 6. Actualiza el PWM del motor.
 * Debe ser llamada periódicamente desde la tarea de FreeRTOS.
 */
void motor_update();

/**
 * @brief Obtiene la velocidad actual calculada por el sensor Hall.
 * @return Velocidad actual en km/h.
 */
float motor_get_speed_kmh();

/**
 * @brief Aplica una decisión de límite de velocidad.
 * Esta función es llamada cuando se recibe un mensaje desde el Core 0.
 * Modifica el estado interno del módulo para limitar el PWM del motor.
 * @param msg Mensaje de inter-core con la información del límite.
 */
void motor_apply_speed_limit(const InterCoreMsg& msg);

// ============================================================================
// TAREA FREERTOS (CORE 1)
// ============================================================================

/**
 * @brief Tarea de FreeRTOS que se ejecuta en el Core 1.
 * Gestiona el ciclo de vida del control del motor:
 * 1. Espera y procesa mensajes de límite de velocidad de la cola.
 * 2. Ejecuta la lógica de control principal llamando a motor_update().
 * 3. Se ejecuta en un bucle infinito para mantener el control en tiempo real.
 * @param pvParameters Parámetros de la tarea (no utilizados en este caso).
 */
void taskMotor(void *pvParameters);

#endif // MOTOR_ADC_TEST_H