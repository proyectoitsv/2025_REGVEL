/* ===========================================================================
   RegVel.ino
   Archivo principal del proyecto RegVel (Limitador de Velocidad por GPS).
   Responsabilidades:
   - Inicializar todos los módulos del sistema.
   - Definir los objetos globales para la comunicación inter-módulo.
   - Crear y asignar las tareas de FreeRTOS a los cores correspondientes.
   - El loop() principal está vacío, ya que toda la lógica asíncrona
     se ejecuta dentro de las tareas.
   ============================================================================= */

// ============================================================================
// INCLUSIÓN DE MÓDULOS
// ============================================================================
#include "config.h"
#include "Gps_bluetooth_test.h"
#include "Motor_ADC_test.h"
#include "Display_test.h"
#include <BluetoothSerial.h> // yo agregue
// ============================================================================
// OBJETOS GLOBALES COMPARTIDOS
// ============================================================================

/**
 * @brief Cola de FreeRTOS para la comunicación inter-core (Core 0 -> Core 1).
 * El módulo GPS escribe mensajes de límite de velocidad en esta cola,
 * y los módulos Motor y Display leen de ella.
 */
QueueHandle_t zone_queue;

BluetoothSerial SerialBT;
// ============================================================================
// FUNCIÓN DE CONFIGURACIÓN INICIAL (setup)
// ============================================================================
void setup() {
  // Inicializar comunicación Serial para debug y mensajes de estado
  Serial.begin(115200);
  delay(1000); // Pequeña espera para estabilizar la conexión serial
  
  Serial.println("\n===========================================");
  Serial.println("     SISTEMA REgVel - INICIANDO");
  Serial.println("===========================================");

  // 1. Crear la cola de comunicación inter-core
  // Es crucial crearla antes de que las tareas intenten usarla.
  zone_queue = xQueueCreate(QUEUE_LENGTH, sizeof(InterCoreMsg));
  if (zone_queue == NULL) {
    Serial.println(FPSTR(LOG_PREFIX_ERROR));
    Serial.println("Error crítico: No se pudo crear la cola inter-core.");
    Serial.println("El sistema no puede continuar. Deteniendo ejecución.");
    while(1) { vTaskDelay(pdMS_TO_TICKS(1000)); } // Detener el sistema
  }
  Serial.println("Cola inter-core creada correctamente.");

  // 2. Inicializar los módulos de hardware y lógica
  // El orden no es crítico aquí, pero es una buena práctica mantenerlo consistente.
  Serial.println("\n--- Inicializando Módulos ---");
  gps_init();
  motor_init();
  display_init();
  Serial.println("--- Todos los módulos inicializados ---\n");

  // 3. Crear las tareas de FreeRTOS y asignarlas a los cores
  Serial.println("--- Creando Tareas de FreeRTOS ---");
  
  // Tarea para el GPS y Bluetooth en el Core 0
  xTaskCreatePinnedToCore(
    taskGPS,                  // Función que implementa la tarea
    "GPSTask",                // Nombre de la tarea (para debug)
    GPS_TASK_STACK,           // Tamaño de la pila de la tarea
    NULL,                     // Parámetros para la tarea (no usados)
    1,                        // Prioridad de la tarea
    NULL,                     // Handle de la tarea (no se necesita guardar)
    0                         // Core donde se ejecutará (Core 0)
  );
  Serial.println("Tarea GPS creada en Core 0.");

  // Tarea para el control del Motor en el Core 1
  xTaskCreatePinnedToCore(
    taskMotor,
    "MotorTask",
    MOTOR_TASK_STACK,
    NULL,
    1,
    NULL,
    1                         // Core donde se ejecutará (Core 1)
  );
  Serial.println("Tarea Motor creada en Core 1.");

  // Tarea para el Display y LEDs en el Core 1
  xTaskCreatePinnedToCore(
    taskDisplay,
    "DisplayTask",
    DISPLAY_TASK_STACK,
    NULL,
    1,
    NULL,
    1                         // Core donde se ejecutará (Core 1)
  );
  Serial.println("Tarea Display creada en Core 1.");
  Serial.println("--- Todas las tareas creadas ---\n");

  // 4. Mensaje final de éxito
  Serial.println("===========================================");
  Serial.println("  SISTEMA REgVel INICIADO CORRECTAMENTE");
  Serial.println("===========================================");
}

// ============================================================================
// BUCLE PRINCIPAL (loop)
// ============================================================================
void loop() {
  // En un sistema basado en tareas (FreeRTOS), el loop principal no debe
  // realizar ninguna tarea activa. Toda la lógica de procesamiento,
  // lectura de sensores y actualización de actuadores se maneja dentro
  // de las tareas que hemos creado.
  // Este loop se ejecuta en la tarea "idle" del Core 1.
  // Lo ponemos en pausa para que consuma la mínima CPU posible.
  vTaskDelay(pdMS_TO_TICKS(10000)); // Dormir durante 10 segundos
}