/* ===========================================================================
   config.h
   Archivo de configuración global y compartida para el proyecto RegVel.
   Contiene definiciones de pines, constantes, umbrales, estructuras de datos
   y configuraciones de hardware para todos los módulos.
   ============================================================================= */

#ifndef CONFIG_H
#define CONFIG_H

// ============================================================================
// LIBRERÍAS DEL SISTEMA
// ============================================================================
#include <Arduino.h>
//#include <BluetoothSerial.h> yo lo comenté
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/queue.h>
#include <freertos/semphr.h>
#include <driver/ledc.h>
#include <driver/adc.h>

// ============================================================================
// CONFIGURACIÓN BLUETOOTH
// ============================================================================
const char BT_NAME[] PROGMEM = "ESP32_GPS_Slave";
const char* HC06_MAC_STR = "00:22:09:01:2C:9E";
const char* HC06_PIN = "1234";

// ============================================================================
// CONFIGURACIÓN DE PINES (GPIO)
// ============================================================================

// --- Pines GPS y Sistema ---
#define LED_STATUS_PIN 2      // LED incorporado para estado general del sistema

// --- Pines Motor y Sensor Hall ---
#define HALL_PIN 34           // Pin de entrada del sensor Hall (interrupt-capable)
#define PEDAL_ADC_PIN 35      // Pin ADC para lectura del pedal (0..4095)
#define MOTOR_PWM_PIN 14      // Pin de salida PWM para el driver del motor

// --- Pines Display 7 Segmentos (CD4511BE) ---
#define DISP_BCD_BIT1_PIN 4   // D0 (LSB)
#define DISP_BCD_BIT2_PIN 19  // D1
#define DISP_BCD_BIT3_PIN 17  // D2
#define DISP_BCD_BIT4_PIN 16  // D3 (MSB)
#define DISP_DIGIT1_PIN 21    // Display 1 (Centenas)
#define DISP_DIGIT2_PIN 22    // Display 2 (Decenas)
#define DISP_DIGIT3_PIN 23    // Display 3 (Unidades)

// --- Pines LEDs de Umbral de Velocidad ---
#define LED_LIM1_PIN 26   // Umbral 1 (40 km/h)
#define LED_LIM2_PIN 25   // Umbral 2 (60 km/h)
#define LED_LIM3_PIN 33   // Umbral 3 (110 km/h)
#define LED_LIM4_PIN 32   // Umbral 4 (130 km/h)

// --- Pines LEDs de Estado del Sistema ---
#define LED_LIMIT_PIN 2   // LED que indica "límite aplicado" (reutiliza LED_STATUS_PIN)
#define LED_OK_PIN 15     // LED OK del sistema

// ============================================================================
// CONFIGURACIÓN HARDWARE Y CONSTANTES FÍSICAS
// ============================================================================

// --- Timer Hardware (GPS) ---
#define TIMER_INTERVAL_US 1000000  // 1 segundo

// --- PWM Motor ---
#define MOTOR_PWM_CHANNEL 0
#define MOTOR_PWM_FREQ 20000       // 20 kHz
#define MOTOR_PWM_RES 8            // 8-bit resolution (0-255)
#define PWM_RESOLUTION_BITS MOTOR_PWM_RES
#define PWM_TIMER LEDC_TIMER_0
#define PWM_CHANNEL LEDC_CHANNEL_0

// --- ADC Pedal ---
#define PEDAL_ADC_ATTENUATION ADC_11db
#define ADC_MAX_READING 4095

// --- Sensor Hall y Física del Vehículo ---
#define WHEEL_CIRCUMFERENCE_M 2.05f // metros (ajustar según diseño)
#define HALL_PULSES_PER_REV 1       // pulsos por revolución del sensor hall
#define MS_PER_CALC 250             // ventana de cálculo de velocidad (ms)

// --- Display 7 Segmentos ---
#define DISP_COMMON_ANODE false     // false = común cátodo
#define DISP_MULTIPLEX_DELAY_US 2000 // microsegundos por dígito (~166Hz total)

// --- Lógica de Control ---
#define DEFAULT_MAX_DUTY 255
#define MIN_SAFE_DUTY 30            // mínimo duty que permitimos por seguridad

// ============================================================================
// UMBRALES Y LÍMITES
// ============================================================================
#define LED_LIM1_THRESHOLD 40
#define LED_LIM2_THRESHOLD 60
#define LED_LIM3_THRESHOLD 110
#define LED_LIM4_THRESHOLD 130

// ============================================================================
// CONFIGURACIÓN FREERTOS
// ============================================================================
#define GPS_TASK_STACK 6144    // Stack para la tarea GPS (Core 0)
#define MOTOR_TASK_STACK 4096  // Stack para la tarea Motor (Core 1)
#define DISPLAY_TASK_STACK 3072 // Stack para la tarea Display (Core 1)
#define QUEUE_LENGTH 10        // Longitud de la cola de mensajes inter-core

// ============================================================================
// ESTRUCTURAS DE DATOS COMPARTIDAS
// ============================================================================

/**
 * @brief Estructura para un fix completo del GPS.
 */
struct GpsFix {
  double lat;
  double lon;
  float speedKph;
  float courseDeg;
  float hdop;
  uint8_t satellites;
  bool valid;
  uint32_t timestamp;
};

/**
 * @brief Mensaje para comunicación inter-core (Core 0 -> Core 1).
 */
struct InterCoreMsg {
  bool inside_zone;
  uint16_t speed_limit;
  bool valid;
};

// ============================================================================
// SISTEMA DE LOGGING
// ============================================================================
enum LogLevel {
  LOG_ERROR = 0,
  LOG_INFO = 1,
  LOG_DEBUG = 2
};

// CONFIGURACIÓN: Cambiar este valor para controlar el nivel de logging
#define LOG_LEVEL LOG_INFO  // ERROR=0, INFO=1, DEBUG=2

// Strings de prefijos en Flash (PROGMEM)
const char LOG_PREFIX_ERROR[] PROGMEM = "[ERROR] ";
const char LOG_PREFIX_INFO[] PROGMEM = "[INFO] ";
const char LOG_PREFIX_DEBUG[] PROGMEM = "[DEBUG] ";

#endif // CONFIG_H